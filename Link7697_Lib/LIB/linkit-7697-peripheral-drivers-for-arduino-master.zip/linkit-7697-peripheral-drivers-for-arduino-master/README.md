# linkit-7697-peripheral-drivers-for-arduino
This repository collects drivers for peripherals used in Arduino with LinkIt 7697.
