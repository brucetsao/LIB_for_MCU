MAX7219\_Dot\_Matrix
====================

Arduino library for MAX7219 display using SPI.

For use with 8x8 dot-matrix displays.


For details about the theory, wiring, schematic, etc. see:

http://www.gammon.com.au/forum/?id=11516

