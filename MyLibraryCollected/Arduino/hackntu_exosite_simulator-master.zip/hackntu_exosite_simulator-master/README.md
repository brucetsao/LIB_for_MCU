# hackntu_exosite_simulator
## How to Use
1. Install Python 2.7 environment in your platform(https://www.python.org/)
2. Execute the script
3. Enter your device serial number
4. Observe the simulation data from Exosite Portal(https://hackntu2016.exosite.com/)
