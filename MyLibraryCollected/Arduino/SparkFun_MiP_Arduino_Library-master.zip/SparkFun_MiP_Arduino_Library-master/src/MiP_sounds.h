/*
 * MiP_sounds.h
 *
 *  Created on: Jul 1, 2014
 *      Author: caseykuhns
 */

#ifndef MIP_SOUNDS_H_
#define MIP_SOUNDS_H_

enum Sounds{
  TEST_SOUND = 1,
  BURP

};






#endif /* MIP_SOUNDS_H_ */
