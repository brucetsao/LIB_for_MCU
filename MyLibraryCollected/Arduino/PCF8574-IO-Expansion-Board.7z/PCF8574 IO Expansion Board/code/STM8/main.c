/********************************************************************************************************
*
* File                : pcf8574.c
* Hardware Environment: 
* Build Environment   : ST Visual Develop 4.1.6
* Version             : V1.0
* By                  : Xiao xian hui
*
*                                  (c) Copyright 2005-2010, WaveShare
*                                       http://www.waveShare.net
*                                          All Rights Reserved
*
*********************************************************************************************************/

#include <stm8s208mb.h>
#include <system.h>
#include <ws_lcd_st7920.h>
#include <ws_pcf8574.h>

void main(void)
{
	u8 i;
	PCF8574_Init();
	st7920LcdInit(); 
	showLine(0,0,lcd_buffer,"PCF8574 Example");
	showLine(0,1,lcd_buffer,"I2C->Parallel");
	showLine(0,2,lcd_buffer,"Focus on LED");
	refreshLCD(lcd_buffer);
	while(1)
	{
		showLine(0,3,lcd_buffer,"Values��0x%x2",(u16)i);
		refreshLCD(lcd_buffer);
		PCF8574_WriteAByte(i);
		i++;
		delay_ms(1000);
	}
}