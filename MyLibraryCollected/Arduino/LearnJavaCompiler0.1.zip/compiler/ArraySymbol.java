/*
 * ArraySymbol.java
 *
 * Created on 2004�~11��21��, �U�� 9:59
 */

/**
 *
 * @author  Administrator
 */
public class ArraySymbol extends BasicSymbol implements Cloneable {
    int iDim; // ����,begin from 1
    int iBound[];
    int iOldBound[];
    /** Creates a new instance of ArraySymbol */
    public ArraySymbol() {
        super();
        iDim=0;
    }
    protected Object clone(){
        ArraySymbol aryCloned;
        aryCloned = new ArraySymbol();
        aryCloned.iSymbolType = iSymbolType;
        aryCloned.iScope = iScope;
        aryCloned.key = key;
        aryCloned.next = next;
        return aryCloned;
    }
    public void addDim(){
        
        
            if( iDim>0 ){
                iOldBound = iBound;
            }
            iDim++;
            iBound = new int[iDim];
            // old old data
            if(iDim!=1){
                for(int i=0;i<iDim-2;i++){
                    iBound[i] = iOldBound[i];
                }
            }
    }
    // set current dim's value
    public void setBound(int iValue){
            iBound[iDim-1] = iValue;
    }
    public String toString(){
        String strAll="";
        for(int i=0;i<iDim;i++){
            if( iBound[i]>0){
                strAll+="[" + iBound[i] + "]";
            }else{
                strAll+="["+"]";
            }
        }
        return "Array" + strAll;
    }
    
}
