/*
 * CurState.java
 *
 * Created on 2004�~11��18��, �U�� 2:48
 */

/**
 *
 * @author  Administrator
 */
public class CurState {
    
    
    /** Creates a new instance of CurState */
    public CurState() {
    }
    
}
