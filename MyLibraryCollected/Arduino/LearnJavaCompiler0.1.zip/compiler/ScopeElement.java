/*
 * ScopeStack.java
 *
 * Created on 2004�~11��20��, �U�� 11:11
 */

/**
 *
 * @author  Administrator
 */
import java.util.*;
public class ScopeElement {
    
    public Vector vKeys;
    public int iScope;
    /** Creates a new instance of ScopeStack */
    public ScopeElement() {
        vKeys = new Vector();
    }
    public boolean addSymbol(String strSymbol){
        // if symbol exist, return false
        if( vKeys.indexOf(strSymbol) < 0 ){ // don't find
            vKeys.add(strSymbol);
            return true;
        }else{
            return false;
        }
    }
    public boolean removeSymbols(){
        String strKey;
        BasicSymbol bs;
        for (int i = 0; i < vKeys.size(); i++){
               strKey = (String) vKeys.elementAt(i);
               bs = (BasicSymbol) Integrator.symbolTable.remove(strKey);
               
               Integrator.symbolTable.strHist += "\n" + bs.toString();
        }
        return true;
    }
}
