/*
 * TestJava.java
 *
 * Created on 2005�~1��10��, �W�� 6:45
 */

/**
 *
 * @author  adminuser
 */
public class TestJava {
    
    /** Creates a new instance of TestJava */
    public TestJava() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i=120,j=230;
        j=i+i;
        j= i+i*i;
    }
    
}
