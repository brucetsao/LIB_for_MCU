/*
 * wl_Util.java
 *
 * Created on 2004�~11��18��, �U�� 3:58
 */

/**
 *
 * @author  Administrator
 */
import java.util.*;

public class Util implements userConstants{
    static int iWarnCount=0;
    static int iErrorCount=0;
    static int iExpressionType=0;
    public ArrayList aryName;
    

    /** Creates a new instance of Util */
    
    public Util() {
        aryName = new ArrayList();
        
    }
    public String getNameByAry(){
        int i;
        String strName="";
        for(i=0;i<aryName.size();i++){
            if(i==0) { strName = (String) aryName.get(i); }
            else {
                strName += "." + aryName.get(i);
            }
        }
        
        return strName;
    }
    public static void DumpCompilerResult(){
        String strResult;
        strResult = "Compiler Result:\nError Count=" + iErrorCount + "\tWarnning Count=" + iWarnCount + "\n";        
        if(iErrorCount>0){
            strResult += "Don't generate code!\n";
        }        
        System.out.println(strResult);
    }
    
    
    public static void showMsg( int iLevel, String m_strMsg){
        
        String strHeader="";

        switch( iLevel ){
            case MSG_INFOR:
                strHeader="<INFOR>";
                break;
            case MSG_DEBUG:
                if( USER_DEBUG!=1) return;
                strHeader="<DEBUG>";
                break;
            case MSG_WARNNING:
                strHeader="<WARNNING>";
                iWarnCount++;
                break;
            case MSG_ERROR:
                strHeader="<ERROR>";
                iErrorCount++;
                break;
            default:
                strHeader="";
               break;
        }
        
        System.out.println(strHeader + m_strMsg);
    }
    public static String symbolTypeToString(int m_iSymbolType){
        String strReturn="";
        if(m_iSymbolType>= JavaParserConstants.tokenImage.length){
            switch(m_iSymbolType){
                case ARRAY_TYPE:
                    strReturn ="Array";
                    break;
                case FUNCTION_TYPE:
                    strReturn ="Function";
                    break;
                default:
                    strReturn ="TypeOutOfRange";
                    break;
            }
            
        }else{
            strReturn=JavaParserConstants.tokenImage[m_iSymbolType].replace('"',' ').trim();
        }
        return strReturn;
    }

}
