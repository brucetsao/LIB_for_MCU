/*
 * CodeGen.java
 *
 * Created on 2005�~1��8��, �W�� 8:26
 */

/**
 *
 * @author  adminuser
 */
import org.apache.bcel.generic.*;
import org.apache.bcel.Constants;
import org.apache.bcel.classfile.*;
import java.util.*;
public class CodeGen implements userConstants,JavaParserConstants {
    public static ClassGen cg;  // current class
    public static ConstantPoolGen cp;
    public static InstructionList il;
    public static MethodGen       mg; // current method
    public static CodeGen codeGen;
    public static InstructionFactory factory ;
    public InstructionHandle ihWhileStart;
    public InstructionHandle ihStart;
    public InstructionHandle ihElse;
    public InstructionHandle ihEnd; 
    
    public Stack stkOP;
    public Stack stkOPs;
    public int iStatementType=STATEMENT_NORMAL;
    BasicSymbol bs;
    /** Creates a new instance of CodeGen */
    public CodeGen() {
        stkOP = new Stack();
        stkOPs = new Stack();
        
    }
    // append instruction by op + type
    public void opAction(int iOP,int iType){
        int iVMType;
        // type transfer
        
        switch(iType){
            case BYTE:
            case SHORT:
                iVMType=INT; break;
            default:
                iVMType = iType; break;
        }
        switch(iOP){
            case PLUS:
                switch(iVMType){
                    case INT:
                        ILPut(new IADD()); break;
                    case LONG:
                        ILPut(new LADD()); break;
                    case FLOAT:
                        ILPut(new FADD()); break;
                    case DOUBLE:
                        ILPut(new DADD()); break;
                    default:
                        break;
                }
                break;
            case MINUS:
                switch(iVMType){
                    case INT:
                        ILPut(new ISUB()); break;
                    case LONG:
                        ILPut(new LSUB()); break;
                    case FLOAT:
                        ILPut(new FSUB()); break;
                    case DOUBLE:
                        ILPut(new DSUB()); break;
                    default:
                        break;
                }
                break;
            case STAR:
                switch(iVMType){
                    case INT:
                        ILPut(new IMUL()); break;
                    case LONG:
                        ILPut(new LMUL()); break;
                    case FLOAT:
                        ILPut(new FMUL()); break;
                    case DOUBLE:
                        ILPut(new DMUL()); break;
                    default:
                        break;
                }
                break;
            case SLASH:
                switch(iVMType){
                    case INT:
                        ILPut(new IDIV()); break;
                    case LONG:
                        ILPut(new LDIV()); break;
                    case FLOAT:
                        ILPut(new FDIV()); break;
                    case DOUBLE:
                        ILPut(new DDIV()); break;
                    default:
                        break;
                }
                break;
            case REM:
                switch(iVMType){
                    case INT:
                        ILPut(new IREM()); break;
                    case LONG:
                        ILPut(new LREM()); break;
                    case FLOAT:
                        ILPut(new FREM()); break;
                    case DOUBLE:
                        ILPut(new DREM()); break;
                    default:
                        break;
                }
                break;
            case GT:
                il.insert(ihElse,new IF_ICMPLE(ihElse));
                break;
            case GE:
                il.insert(ihElse,new IF_ICMPLT(ihElse));
                break;
            case LT:
                il.insert(ihElse,new IF_ICMPGE(ihElse));
                break;
            case LE:
                il.insert(ihElse,new IF_ICMPGT(ihElse));
                break;
            case EQ:
                il.insert(ihElse,new IF_ICMPNE(ihElse));
                break;
            case NE:
                il.insert(ihElse,new IF_ICMPEQ(ihElse));
                break;
                
                
        }
    }
    public void ILPut(Instruction i){
        switch(iStatementType){
            case STATEMENT_NORMAL:
                Util.showMsg(MSG_DEBUG,"StateNormal");
                il.append(i);
                break;
            case STATEMENT_IFEXP:
                Util.showMsg(MSG_DEBUG,"StateIFEXP");
                il.insert(ihStart,i);
                break;
            case STATEMENT_IFBLOCK:
                Util.showMsg(MSG_DEBUG,"StateIFBLOCK");
                il.insert(ihElse,i);
                break;
            case STATEMENT_IFELSE:
                Util.showMsg(MSG_DEBUG,"StateIFELSE");
                il.insert(ihEnd,i);
                break;
        }
    }
    // bStore: store or load
    // if it is a symbol. get it's type from object, if not, use m_iSymbolType
    public void SymbolAction(boolean bStore,String symName,int m_iSymbolType){
        int iSymType;
        int iVMType;
        bs = (BasicSymbol) Integrator.symbolTable.get(symName);

        if(bs== null){
            iSymType = m_iSymbolType;
        }else{
            iSymType = bs.iSymbolType;
        }
        // type transfer
        switch(iSymType){
            case BYTE:
            case SHORT:
                iVMType=INT; break;
            default:
                iVMType = iSymType; break;
        }
        
        if(bs==null){
            
                //il.append(new LDC(cp.addInteger(new Integer(symName).intValue())));
                switch(iVMType){
                    case INT:
                        ILPut( factory.createConstant(new Integer(symName)));
                        break;
                    case LONG:
                        ILPut( factory.createConstant(new Long(symName)));
                        break;
                    case FLOAT:
                        ILPut( factory.createConstant(new Float(symName)));
                        break;
                    case DOUBLE:
                        ILPut( factory.createConstant(new Double(symName)));
                        break;
                    case BOOLEAN:
                        ILPut( factory.createConstant(new Boolean(symName)));
                    default:
                        break;
                        
                }
                
            
        }else{
            if(bStore){//sym,store
                ILPut(factory.createStore(tokenKindToType(iSymType),bs.lg.getIndex()));
                //il.append(new ISTORE(bs.lg.getIndex()));        
            }else{ //sym,load
                ILPut(factory.createLoad(tokenKindToType(iSymType),bs.lg.getIndex()));
                //il.append(new ILOAD(bs.lg.getIndex()));
            }
        }
               
    }
    private void PopByType(int iType,Stack stk,Stack stkNew,boolean bFirst){
        int iOpCount=0;
        switch( iType ){
            case PLUS:
            case MINUS:
            case SLASH:
            case STAR:
            case REM:
            case GT:
            case GE:
            case LE:
            case LT:
            case EQ:
            case NE:
                iOpCount=2;
                break;
            default:
                iOpCount=1;
        }
        if(! bFirst){ iOpCount--;}
        for(int i=0;i<iOpCount;i++){
            if(stkNew!=null){
                stkNew.push(stk.pop());
            }else{
                stk.pop();
            }
            
        }
    }
    // �ѩ��u���v�B�٦� default �� stack �O�ѥk�쥪�A�ҥH�n�� reorder
    //�ثe�u����ѥ���k�A�S�����u���v���P�_
    public void StackReOrder(){
        
        Stack stkOPTmp,stkOPsTmp;
        Integer iInt;
        // check if stack have no value
        if(stkOP.size()==0 ) { return; }
        stkOPTmp = (Stack)stkOP.clone(); 
        stkOPsTmp = (Stack)stkOPs.clone(); 
        
        // �p�G index=0 �O = ���ܡA�n�O�d
        boolean bFirst=true;
        while(stkOP.size()>0){
            iInt = (Integer) stkOP.peek();
            if( iInt.intValue()!=ASSIGN) {
                stkOP.pop();
                PopByType(iInt.intValue(),stkOPs,null,bFirst);
                
            }else{
                break;
            }
            bFirst=false;
        }
        bFirst=true;
        while(stkOPTmp.size()>0){
            iInt = (Integer) stkOPTmp.peek();
            if( iInt.intValue()!=ASSIGN) {
                stkOP.push(stkOPTmp.pop());
                PopByType(iInt.intValue(),stkOPsTmp,stkOPs,bFirst);
            }else{
                break;
            }
            bFirst=false;
        }
        // 

    }
    // ��� OPs ��,�ѤU��W�Ĥ@���ܼơA�Ǧ^ type
    public int GetOPsType(){
        String strVar;
        BasicSymbol bs;
        int iVarType;
        int iLoc=0;
        while( stkOPs.size()>iLoc){
            strVar = (String)stkOPs.get(iLoc);
            iLoc++;
            bs = (BasicSymbol) Integrator.symbolTable.get(strVar);
            if( bs!=null ){ // =
                iVarType = bs.iSymbolType;
                return iVarType;
            }
        }
        return 0;
    }
    // �B�z���� OP
    public void OPGens(){
        String strVar;
        int iVarType=0;
        boolean bFirst=true;
        StackReOrder();
        iVarType = GetOPsType();
        
        while(!stkOP.isEmpty()){
            OPGen(bFirst,iVarType);
            bFirst=false;
        }
        
    }
    // insert op operation code to InstructionList
    // �ھ� OP �B�z�� OPs stack,
    //using iType to handle type
    public void OPGen(boolean bFirst,int iType){
        Integer iOP; // �B�⤸
        String strOP1,strOP2; // �B��l
        int iInt;
        if(bFirst){ // first OP handle, need to pop first
                strOP1=(String)stkOPs.pop();
                //����� case , i=5 , or i=a+b
                bs = (BasicSymbol) Integrator.symbolTable.get(strOP1);
                if(bs!= null){ // i=a+b
                    ILPut(factory.createLoad(tokenKindToType(iType),bs.lg.getIndex()));
                    //il.append(new ILOAD(bs.lg.getIndex()));
                }else{
                    SymbolAction(true,strOP1,iType);    
                    //iInt = new Integer(strOP1).intValue();
                    //il.append(new LDC(cp.addInteger(iInt)));
                }            
        }
        iOP = (Integer)stkOP.pop();
        Util.showMsg(MSG_DEBUG,"OPGen:" + iOP.intValue());
        
        
        switch(iOP.intValue()){
            case ASSIGN: // =
                strOP2=(String)stkOPs.pop(); // must be a symbol
                SymbolAction(true,strOP2,iOP.intValue());    

                break;
            case PLUS: // +
                strOP2=(String)stkOPs.pop();
                
                //iInt = new Integer(strOP2).intValue();
                //il.append(new LDC(cp.addInteger(iInt)));
                //il.append(new IADD());
                SymbolAction(false,strOP2,iType);
                opAction(iOP.intValue(),iType);
                break;
            case MINUS: // -
                strOP2=(String)stkOPs.pop();
                SymbolAction(false,strOP2,iType);
                opAction(iOP.intValue(),iType);
                break;
            case STAR: //*
                strOP2=(String)stkOPs.pop();
                SymbolAction(false,strOP2,iType);
                opAction(iOP.intValue(),iType);
                break;
            case SLASH: //  /
                strOP2=(String)stkOPs.pop();
                SymbolAction(false,strOP2,iType);
                opAction(iOP.intValue(),iType);
                break;
            case REM: //%
                strOP2=(String)stkOPs.pop();
                SymbolAction(false,strOP2,iType);
                opAction(iOP.intValue(),iType);
                break;
            case GT:
            case GE:
            case LE:
            case LT:
            case EQ:
            case NE:                
                strOP2=(String)stkOPs.pop();
                SymbolAction(false,strOP2,iType);
                opAction(iOP.intValue(),iType);
                break;

               
        }
    }
    public JavaClass DefaultClassGen(){
        //create a default java class, then modify it step by step
        cg = new ClassGen("Noname", "java.lang.Object",
				      "<generated>", Constants.ACC_PUBLIC |
				      Constants.ACC_SUPER,
				      null);
        factory = new InstructionFactory(cg);
        //cg.addEmptyConstructor(Constants.ACC_PUBLIC);
        return cg.getJavaClass();
    }
    public MethodGen DefaultMethodGen(){
        cp = cg.getConstantPool(); // cg creates constant pool
        il = new InstructionList();
        mg = new MethodGen(Constants.ACC_STATIC |
				       Constants.ACC_PUBLIC,// access flags
				       Type.VOID,              // return type
				       new Type[] {            // argument types
					 new ArrayType(Type.STRING, 1) 
				       },
				       new String[] { "argv" }, // arg names
				       "main", "Noname",    // method, class
				       il, cp);

        mg.setMaxLocals();
        //cg.addMethod(mg.getMethod()); // �@�w�n�� localvariable
        return mg;
    }
    // using tokenkind to build Field
    public Field DefaultFieldGen(int access_flags,int m_iReturnType,java.lang.String name){
        FieldGen fg;
        Type type = tokenKindToType(m_iReturnType);
        fg = new FieldGen(access_flags, type, name, cp);
        if(fg==null){
            fg=null;
        }
        return fg.getField();
    }
    public Type tokenKindToType(int m_iReturnType){
        Type retType;
        switch( m_iReturnType ){
            case BOOLEAN:
                retType = Type.BOOLEAN; break;
            case CHAR:
                retType = Type.CHAR; break;
            case BYTE:
                retType = Type.BYTE; break;
            case SHORT:
                retType = Type.SHORT; break;
            case INT:
                retType = Type.INT; break;
            case LONG:
               retType = Type.LONG; break;
            case FLOAT:
                retType = Type.FLOAT; break;
            case DOUBLE:
                retType = Type.DOUBLE; break;
            default:
                retType = Type.VOID; break;
                
                
        }      
        return retType;
    }
    public static int strToAccessFlag(String strPar){
        int iAccessFlag=0;
        if(strPar.equals("public")){ iAccessFlag=Constants.ACC_PUBLIC ;}
        if(strPar.equals("protected")){ iAccessFlag=Constants.ACC_PROTECTED ;}
        if(strPar.equals("private")){ iAccessFlag=Constants.ACC_PRIVATE ;}
        if(strPar.equals("static")){ iAccessFlag=Constants.ACC_STATIC ;}
        if(strPar.equals("abstract")){ iAccessFlag=Constants.ACC_ABSTRACT ;}
        if(strPar.equals("final")){ iAccessFlag=Constants.ACC_FINAL ;}
        if(strPar.equals("native")){ iAccessFlag=Constants.ACC_NATIVE ;}
        if(strPar.equals("synchronized")){ iAccessFlag=Constants.ACC_SYNCHRONIZED ;}
        if(strPar.equals("strictfp")){ iAccessFlag=Constants.ACC_STRICT ;}
        return iAccessFlag;
    }
    public void ifExp(){
        iStatementType = STATEMENT_IFEXP;
        ihWhileStart = il.append(InstructionConstants.NOP);        
        ihStart = il.append(InstructionConstants.NOP);
        ihElse = il.append(InstructionConstants.NOP);
        ihEnd = il.append(InstructionConstants.NOP);
    }
    public void ifBlock(){
        iStatementType =STATEMENT_IFBLOCK;
    }
    public void ifElse(){
        iStatementType = STATEMENT_IFELSE;
        il.insert(ihElse,new GOTO(ihEnd));
    }
    public void ifEnd(){
        iStatementType = STATEMENT_NORMAL;
    }
    public void ifWhileEnd(){
        il.insert(ihElse,new GOTO(ihEnd));
        iStatementType = STATEMENT_NORMAL;
    }    
    public void ifWhileBreak(){
        il.insert(ihElse,new GOTO(ihEnd));
        iStatementType = STATEMENT_NORMAL;
    }    
    public static void DumpClassFile(){
        // write data to disk
        
        Integrator.clsSymbol.dump();
    }
    
}
