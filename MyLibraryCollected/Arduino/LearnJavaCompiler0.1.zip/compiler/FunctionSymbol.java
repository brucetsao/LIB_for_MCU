/*
 * FunctionSymbol.java
 *
 * Created on 2004�~11��22��, �W�� 12:52
 */

/**
 *
 * @author  Administrator
 */
import java.util.*;
import org.apache.bcel.generic.*;
import org.apache.bcel.Constants;
import org.apache.bcel.classfile.*;
public class FunctionSymbol extends BasicSymbol implements JavaParserConstants {
    
    public Vector vPar;
    public int iReturnType;
    MethodGen mg;
    /** Creates a new instance of FunctionSymbol */
    public FunctionSymbol() {
        super();
        vPar = new Vector();
  
    }
    public void ReNew(){
        iScope = 0;
        iSymbolType=FUNCTION_TYPE;
        iReturnType=0;
	key="";
        vPar.clear();
    }
    protected Object clone(){
        
        FunctionSymbol fsCloned;
        fsCloned = new FunctionSymbol();
        fsCloned.iReturnType = iReturnType;
        fsCloned.iScope = iScope;
        fsCloned.iSymbolType = iSymbolType;
        fsCloned.key = key;
        Util.showMsg(MSG_DEBUG,"Function Parameter Need Clone" + vPar.toString());
        fsCloned.vPar = (Vector) (vPar.clone());
        fsCloned.mg = (MethodGen)( mg.clone());
        /*for( int i=0;i< vPar.size(); i++){
            fsCloned.vPar.add(vPar.get(i));
        }*/
        
        Util.showMsg(MSG_DEBUG,"Function Parameter Cloned" + fsCloned.vPar.toString());
        return fsCloned;        
    }

    public void addPar(BasicSymbol m_bs){
        // need copy first
        //BasicSymbol newValue=new BasicSymbol(m_bs.iSymbolType);
        BasicSymbol newValue=(BasicSymbol)(m_bs.clone());

        
        newValue.iScope = m_bs.iScope;
        newValue.key = m_bs.key;
        vPar.add(newValue);
      
    }
    public int GetParCount(){
        return vPar.size();
    }
    

    public void setReturnType(int m_iReturnType){
        iReturnType = m_iReturnType;
        Type retType = CodeGen.codeGen.tokenKindToType(iReturnType);
        mg.setReturnType(retType);
    }
    
    public String toString(){
        String strAll="";
        String strImage;
        String strReturnType;
        BasicSymbol bs;
        for(int i=0;i< vPar.size() ;i++){
            bs = (BasicSymbol) vPar.get(i);
            if(bs.iSymbolLocation == SYM_LOC_PAR){
                strImage = Util.symbolTypeToString(bs.iSymbolType);
                if(i==0){
                    strAll = strImage + " " + bs.key ;
                }else{
                    strAll += "," + strImage + " " + bs.key ;
                }
            }
        }
        strReturnType = JavaParserConstants.tokenImage[iReturnType];
        strReturnType = strReturnType.replace('"',' ');
        strAll = super.toString() + "\n" +  strReturnType  + "(" + strAll + ")";
        return strAll;
    }
    public void init(){
        mg = Integrator.codeGen.DefaultMethodGen();
        //jc.dump("abc.class");
    }    
        public void setPar(int iTypeID,String strPar){
        int i;
        short iAccessFlag=0;
        
        switch( iTypeID){
            case TYPE_ACC_NAME: // string to access class
                mg.setAccessFlags(Integrator.codeGen.strToAccessFlag(strPar));
                break;
            case TYPE_CLS_NAME: // set class name
                mg.setClassName(strPar);
                break;
            case TYPE_METHOD_NAME:
                mg.setName(strPar);
                key=strPar;
                break;
            case TYPE_PAR:
                String strPars[];
                ArrayList aryPar= new ArrayList();;
                ArrayList aryParType = new ArrayList();
                BasicSymbol bs;
                Type[] parType;
                
                for(i=0;i< vPar.size() ;i++){
                    bs = (BasicSymbol) vPar.get(i);
                    aryPar.add(bs.key);
                    aryParType.add( CodeGen.codeGen.tokenKindToType(bs.iSymbolType));
                }
                mg.setArgumentNames((java.lang.String[])aryPar.toArray());
                mg.setArgumentTypes((Type[]) aryParType.toArray());
                break;
          
            default:
                break;
                
        }
        
    }
}
