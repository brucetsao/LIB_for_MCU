/*
 * SymbolTable.java
 *
 * Created on 2004�~11��18��, �U�� 10:56
 */

/**
 *
 * @author  Administrator
 */
import java.util.*;
import org.apache.bcel.generic.*;
import org.apache.bcel.Constants;
import org.apache.bcel.classfile.*;
public class SymbolTable extends Hashtable implements userConstants{
    int iCurScope;
    Stack stScope;
    Stack stGramma; // record gramma stack in order to find out current position in gramma
    ScopeElement se;
    BasicSymbol bs;
    public String strHist;
    
    
    /** Creates a new instance of SymbolTable */
    public SymbolTable() {
        iCurScope=0;
        stScope = new Stack();
        stGramma = new Stack();
        se = new ScopeElement();
        
        se.iScope = iCurScope;
        stScope.push(se);
        strHist="";
      
    }
    public Object put(BasicSymbol value){
        String key="";
        key = value.key;
        //System.out.println("Before single put" + key);
        return put(key,value);
    }
    public Object put(String key,BasicSymbol value){
        // check if dupicate first
        if( get(key)!=null ){
            Util.showMsg(MSG_ERROR,"Dupicate declaration:\tSymbol=" + key );
            return null;
        }
        value.iScope = iCurScope;
        // teacher requirement: print a msg when global variable declare
        if(findGrammaStack("FieldDeclaration")) {
            Util.showMsg(MSG_INFOR,"Class variable declare: symbol=" + key);
            value.iSymbolLocation = SYM_LOC_FIELD;
            CodeGen.cg.addField(Integrator.codeGen.DefaultFieldGen(Constants.ACC_PUBLIC,value.iSymbolType,value.key));
            
            
            // type
            
        }else if(findGrammaStack("MethodDeclarator")){ // methold parameter
            value.iSymbolLocation = SYM_LOC_PAR;
            
        }else if(findGrammaStack("MethodDeclaration_1")){ // methold declare
            CodeGen.mg.setMaxStack();
            CodeGen.il.append(new RETURN());
            CodeGen.cg.addMethod(CodeGen.mg.getMethod());
            
        }else{ // local variable
            value.iSymbolLocation = SYM_LOC_LOCAL;
            value.lg = CodeGen.mg.addLocalVariable(key,CodeGen.codeGen.tokenKindToType(value.iSymbolType),null,null);
            
            //CodeGen.il.append(new ICONST(1));
            //CodeGen.il.append(new ISTORE(lg.getIndex()));
            
            
             
        }
        // code gen
        
        
        //copy static basic symbol data
        BasicSymbol newValue;
        newValue= (BasicSymbol)(value.clone());   
       

        if(se.addSymbol(key)==false){
            return null;
        }
        //System.out.println("before put key=" + key +",value.key=" + newValue.key);
        return super.put(key,newValue);
    }
    public void enterScope(){
        iCurScope++;
        se = new ScopeElement();
        se.iScope = iCurScope;
        stScope.push(se);
        //Util.showMsg(MSG_INFOR,"Enter Scope ID=" + iCurScope);
    }
    public void leaveScope(){
        iCurScope--;
        se = (ScopeElement) stScope.pop();
        se.removeSymbols();
        //Util.showMsg(MSG_INFOR,"Leave Scope ID=" + iCurScope);
           
    }
    public void enterGramma(String m_strGramma){
        //Util.showMsg(MSG_DEBUG,"EnterGramma " + m_strGramma + ",Size=" + stGramma.size() );
        stGramma.add(m_strGramma);
    }
    public void leaveGramma(){
        //Util.showMsg(MSG_DEBUG,"LeaveGramma " + stGramma.pop() + ",Size=" + stGramma.size() );
        
    }
    public void leaveGramma(String m_strGramma){
        String strPop;
        strPop= (String)stGramma.pop();
        if(! strPop.equals(m_strGramma)) {
            //Util.showMsg(MSG_DEBUG,"Not equal LeaveGramma Want=" + m_strGramma + ",Stack=" + strPop + ",Size=" + stGramma.size() );
        }else{
            //Util.showMsg(MSG_DEBUG,"LeaveGramma " + strPop + ",Size=" + stGramma.size() );    
            return;
        }
        while(! strPop.equals(m_strGramma)){
            if( stGramma.size()>0){
                strPop=(String)stGramma.pop();
                if(! strPop.equals(m_strGramma)) {
                    //Util.showMsg(MSG_DEBUG,"Not equal LeaveGramma Want=" + m_strGramma + ",Stack=" + strPop + ",Size=" + stGramma.size() );
                }else{
                    //Util.showMsg(MSG_DEBUG,"LeaveGramma " + strPop + ",Size=" + stGramma.size() );    
                }
            }else{
                break;
            }
        }

        
        
    }
    public boolean findGrammaStack(String m_strGramma){
        if( stGramma.contains(m_strGramma)==true) return true;
        else return false;
    }
    public boolean findGrammaStack(String m_strGramma[]){
        int i;
        int iTrueCount=0;
        for(i=0;i<m_strGramma.length ;i++){
            if( stGramma.contains(m_strGramma[i])==true) iTrueCount++;
        }
        if( m_strGramma.length== iTrueCount ) return true;
        else return false;
    }

    // check if  symbol have this type
    public void checkExist(String strKey, int m_iSymbolType){
        String strError="";
        
        
        // all symbol table don't have this key, print error msg
        bs = (BasicSymbol) get(strKey);
        if(bs==null){
            switch(m_iSymbolType){
                case FUNCTION_TYPE:
                    strError = "can't resolve function symbol,symbol name " + strKey;
                    break;
                default: //default
                    strError = "can't resolve symbol,symbol name " + strKey;
                    break;                    
            }
            
            Util.showMsg(MSG_ERROR,strError);
            return ;
        }
        if( m_iSymbolType == 0 ) return ;
        // find in stack
        
    }    
    public void checkExist(BasicSymbol m_bs){
        String strError;
        // all symbol table don't have this key, print error msg
        if(get(m_bs.key)==null){
            strError = "can't resolve symbol,symbol name " + m_bs.key + " ";
            return ;
        }
    }    
    public String toString(){
    //public static void print(String msg, Hashtable box, boolean all) {
        String strAll="";
        if (isEmpty())
            strAll = "The Symbol table is empty";
        else {
            strAll += "There are " + size()  + " element:\n";
            for(Enumeration e = elements();e.hasMoreElements(); strAll += "\n" + e.nextElement());
            strAll +=  "\nHist:\n" + strHist;
            
        }
        return strAll;
    }
}
