public class test_sample1 {
    
    public test_sample1() {
    }
    
    public static void main() {
        int i;
        int j;
        int k[];
        float f;
        i=10;
        
        
	if(true){

        //ab(3);
        }
    }
    
}
