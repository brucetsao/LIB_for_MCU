/*
 * UserConstants.java
 *
 * Created on 2004�~11��22��, �U�� 10:09
 */

/**
 *
 * @author  Administrator
 */
public interface userConstants {
    int USER_DEBUG=0;
    int COMPLEX_TYPE_START = 1000;
    int ARRAY_TYPE = COMPLEX_TYPE_START+1;
    int FUNCTION_TYPE = COMPLEX_TYPE_START +2;
    int PARID_START = 2000;
    int CHECK_PrimaryPrefix= PARID_START+1;
    int MSG_INFOR= PARID_START+2;
    int MSG_DEBUG= PARID_START+3;
    int MSG_WARNNING= PARID_START+4;
    int MSG_ERROR= PARID_START+5;
    int ACT_SETSYMBOLTYPE=1;
    int ACT_NAME_START=2;
    int ACT_NAME_CONT=3;
    int ACT_NAME_END=4;
    int ACT_OPS=5;
    int ACT_OP=6;
    int ACT_OP_CAL=7;
    int ACT_IF_EXP=8;
    int ACT_IF_BLOCK=9;
    int ACT_IF_ELSE=10;
    int ACT_IF_END=11;
    int ACT_IF_WHILEEND=12;
    int ACT_IF_WHILEBREAK=13;
    
    int TYPE_ACC_NAME=1;
    int TYPE_CLS_NAME=2;
    int TYPE_EXT_NAME=3;
    int TYPE_METHOD_NAME=4;
    int TYPE_RETTYPE_NAME=5;
    int TYPE_PAR=6;
    int SYM_LOC_FIELD=1;
    int SYM_LOC_LOCAL=2;
    int SYM_LOC_PAR=3;
    
    int STATEMENT_NORMAL=0;
    int STATEMENT_IFEXP=1;
    int STATEMENT_IFBLOCK=2;
    int STATEMENT_IFELSE=3;
    
    


}
