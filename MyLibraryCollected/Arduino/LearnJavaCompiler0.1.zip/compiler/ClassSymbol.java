/*
 * FunctionSymbol.java
 *
 * Created on 2004�~11��22��, �W�� 12:52
 */

/**
 *
 * @author  Administrator
 */
import java.util.*;
import org.apache.bcel.generic.*;
import org.apache.bcel.Constants;
import org.apache.bcel.classfile.*;
public class ClassSymbol extends BasicSymbol {
    
    //JavaClass jc;
    public int iReturnType;
    /** Creates a new instance of FunctionSymbol */
    public ClassSymbol() {
        super();
        
  
    }
    public void init(){
        Integrator.codeGen.DefaultClassGen();
        //jc.dump("abc.class");
    }
    public void dump(){
        Util.showMsg(MSG_INFOR,"Dump Class to disk");
        try {
          
          CodeGen.cg.getJavaClass().dump( key + ".class");
        } catch(java.io.IOException e) { 
            //System.err.println(e); 
            Util.showMsg(MSG_ERROR,"Dump Class to disk Exception" + e.toString());
        }  
        
    }
    public void setPar(int iTypeID,String strPar){
        int i;
        short iAccessFlag=0;
        switch( iTypeID){
            case TYPE_ACC_NAME: // string to access class
                if(strPar.equals("abstract")) {iAccessFlag=Constants.ACC_ABSTRACT ;}
                if(strPar.equals("final")){ iAccessFlag=Constants.ACC_FINAL;}
                if(strPar.equals("public")){ iAccessFlag=Constants.ACC_PUBLIC ;}
                if(strPar.equals("strictfp")) {iAccessFlag=Constants.ACC_STATIC ;}
                CodeGen.cg.setAccessFlags((short)iAccessFlag);
                break;
            case TYPE_CLS_NAME: // set class name
                CodeGen.cg.setClassName(strPar);
                CodeGen.cg.getJavaClass().setClassName(strPar);
                key=strPar;
                break;
            case TYPE_EXT_NAME: //set ext name
                String strName;
                strName = Integrator.util.getNameByAry();
                if( strName.equals("") ) strName = strPar;  // ���S�� a.b.c �� format ���ɭԡA�٬O�|�Ǧ^ token
                //CodeGen.cg.setSuperclassName(strName);
                break;
              
                
        }
        
    }
    public void ReNew(){
        iScope = 0;
        iSymbolType=FUNCTION_TYPE;
        iReturnType=0;
	key="";
        
    }
    protected Object clone(){
        
        ClassSymbol fsCloned;
        fsCloned = new ClassSymbol();
        fsCloned.iReturnType = iReturnType;
        fsCloned.iScope = iScope;
        fsCloned.iSymbolType = iSymbolType;
        fsCloned.key = key;
        // class �S����k clone, using global

        return fsCloned;        
    }


    
    public void setReturnType(int m_iReturnType){
        iReturnType = m_iReturnType;
    }
    
    public String toString(){
        String strAll="";
        String strImage;
        String strReturnType;
        BasicSymbol bs;

        strReturnType = JavaParserConstants.tokenImage[iReturnType];
        strReturnType = strReturnType.replace('"',' ');
        strAll = super.toString() + "\n" +  strReturnType  + "(" + strAll + ")";
        return strAll;
    }
}
