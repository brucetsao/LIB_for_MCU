import org.apache.bcel.Constants;
import org.apache.bcel.generic.*;

public class BasicSymbol implements userConstants, Cloneable {

    public String key; 
    Object binding; 
    public int iScope;
    BasicSymbol next;    
    LocalVariableGen lg;
    /** Creates a new instance of BasicSymbol */
    public int iSymbolType;
    public int iSymbolLocation; // field, local variable, method parameter
    public int iSymbolAccessFlag;
    //public Object objSd; // symbol detail
    public BasicSymbol() {
        iSymbolType=0;
        iSymbolAccessFlag = Constants.ACC_PUBLIC;
        lg=null;
    }
    protected Object clone(){
        BasicSymbol bsCloned;
        bsCloned = new BasicSymbol();
        bsCloned.iSymbolType = iSymbolType;
        bsCloned.iSymbolLocation = iSymbolLocation;
        bsCloned.iSymbolAccessFlag = iSymbolAccessFlag;
        bsCloned.iScope = iScope;
        bsCloned.key = key;
        bsCloned.next = next;
        bsCloned.lg = lg;
        return bsCloned;
        
    }
    public BasicSymbol(int m_iSymbolType){
        setSymbolType(m_iSymbolType);
    }
    public void setSymbolType( int m_iSymbolType){
        iSymbolType = m_iSymbolType;
    }
    public String toString(){
        String strAll;
        strAll = "Key=" + key + ",type=" + Util.symbolTypeToString(iSymbolType) + ",Scope=" + iScope;
        return strAll;
    }
    public void codeGen(){
        
    }
}
