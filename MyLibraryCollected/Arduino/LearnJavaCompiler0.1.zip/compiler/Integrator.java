/*
 * Integrator.java
 *
 * Created on 2004�~11��24��, �W�� 6:22
 */

/**
 *
 * @author  Administrator
 */
public class Integrator implements userConstants{
    public static BasicSymbol curSymbol; // current symbol 
    public static FunctionSymbol funSymbol; // current function-symbol
    public static ClassSymbol clsSymbol; //current class-symbol
    
    public static SymbolTable symbolTable;
    public static CodeGen codeGen;
    public static Util util;
    /** Creates a new instance of Integrator */
    public Integrator() {
        symbolTable=new SymbolTable();
        curSymbol = new BasicSymbol();
        funSymbol = new FunctionSymbol();
        clsSymbol = new ClassSymbol();
        
        util = new Util();
        codeGen = new CodeGen();
        codeGen.codeGen = codeGen;
        
        
    }
    public void DumpSymbolTable(){
        Util.showMsg(MSG_INFOR, symbolTable.toString());
    }



}
