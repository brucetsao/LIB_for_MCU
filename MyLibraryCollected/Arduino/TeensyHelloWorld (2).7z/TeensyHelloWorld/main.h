#ifndef __MAIN_H_

#define __MAIN_H_

//#define uint8_t unsigned char
//#define uint16_t unsigned int

#endif